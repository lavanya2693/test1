
public class DBConnection {
	
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL="jdbc:mysql://localhost:3306/Test?useSSL=false";
	
	static final String DATABASE_USERNAME="root";
	static final String DATABASE_PASSWORD="root";
	
	public static void main(String[] args){
		try{
			Connection dbconn=DriverManager.getConnection(DB_URL,DATABASE_USERNAME,DATABASE_PASSWORD);
			if(dbconn!=null){
				System.out.println("connected");
			}
		}
	}

}
